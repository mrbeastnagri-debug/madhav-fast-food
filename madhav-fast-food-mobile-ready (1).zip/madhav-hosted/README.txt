MADHAV FAST FOOD - MOBILE READY PACKAGE

This is a mobile-first Progressive Web App (PWA).

IMPORTANT:
Opening index.html directly from a phone's file manager is NOT the same as hosting it. PWA features, secure storage behavior, and online access require HTTPS hosting.

Deploy this folder to any static HTTPS host such as GitHub Pages, Netlify, Vercel, or Cloudflare Pages.

After deployment, open the HTTPS URL on Android Chrome and use "Add to Home screen" / "Install app".

CURRENT DATA MODEL:
The prototype stores menu, cart, and orders in browser localStorage. This means customer and owner data are NOT shared across different phones.
For a real restaurant launch, connect the app to a backend such as Supabase and secure owner authentication.
